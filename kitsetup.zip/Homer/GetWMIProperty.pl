$oWMI = Win32::OLE->GetObject('winmgmts:\\\\.');
$oSystems = $oWMI->InstancesOf($p1);
@oSystems = in $oSystems;
$oSystem = $oSystems[0];
return $oSystem->{$p2};