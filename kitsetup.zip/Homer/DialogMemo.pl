my $StandAlone = 0;
if ($StandAlone) {
use strict;
use warnings;
use Win32::GUI;
}
my ($p1, $p2, $p3, $p4) = $StandAlone ? ('Memo', "This is line 1\r\nline 2 is here", 0, 0) : ($p1, $p2, $p3, $p4);

Win32::GUI->import(qw(ES_WANTRETURN GW_HWNDNEXT GW_HWNDPREV GW_HWNDLAST GW_HWNDFIRST));
package Win32::GUI;

my $Result = '';
my $Keyboard = Win32::GUI::AcceleratorTable->new(Escape => sub {return -1;});
my $Dlg = Win32::GUI::DialogBox->new(-name => 'Dlg', -title => $p1, -width => 434, -height => 483, -accel => $Keyboard, -onTerminate => sub {return -1;}, -dialogui => 1);
$Dlg->AddTextfield(-name => 'Memo', -text => $p2, -left => 14, -top => 14, -width => 400, -height => 400, -tabstop => 1, -multiline => 1, -vscroll => 1, -autovscroll => 1, -addstyle => ES_WANTRETURN);
$Dlg->AddButton(-name => 'OK', -caption => 'OK',	-left => 110, -top => 428, -width => 100, -height => 16, -align => 'center', -valign => 'center', -tabstop => 1, -ok => 1, -default => 1, -onClick => sub {$Result = $Dlg->Memo->Text(); return -1;});
$Dlg->AddButton(-name => 'Cancel', -caption => 'Cancel',	-left => 218, -top => 428, -width => 100, -height => 16, -align => 'center', -valign => 'center', -tabstop => 1, -cancel => 1, -onClick => sub {return -1;});

$Dlg->Memo->SetFocus();
$Dlg->Center();
$Dlg->Show();
$Dlg->SetForegroundWindow();
Win32::GUI::Dialog();
$Dlg->DESTROY();

if ($StandAlone) {
print "Result=$Result\n";
}
else {
scalar $Result;
}
