my $StandAlone = 0;
if ($StandAlone) {
use strict;
use warnings;
use Win32::GUI;
}
my ($p1, $p2, $p3, $p4) = $StandAlone ? ('Fields', "field1\007field2\007field3", "value1\007value2\007value3", 0) : ($p1, $p2, $p3, $p4);

Win32::GUI->import(qw(ES_WANTRETURN GW_HWNDNEXT GW_HWNDPREV GW_HWNDLAST GW_HWNDFIRST));
package Win32::GUI;

my $Result = '';
my ($width, $height) = (293, 99);
my @names = split(/\007/, $p2);
my @values = split(/\007/, $p3);
my $count = @names;
$height += 24 * ($count - 1);

my $Dlg = Win32::GUI::DialogBox->new(-name => 'Dlg', -title => $p1, -width => $width, -height => $height, -onTerminate => sub {return -1;});
my $row = 14;
my $GWL_ID = -12;
my $id = 3;
my $i = 0;
while ($i < $count) {
my ($name, $value) = ($names[$i], $values[$i]);
$i ++;
my $label = $name . ':';
$name = 'Label' . $i;
$Dlg->AddLabel(-name => $name, -text => $label, -left => 14, -top => $row, -width => 53, -height => 16, -align => 'left', -tabstop => 0);
$Dlg->$name->SetWindowLong($GWL_ID, $id++);
$name = 'Input' . $i;
$Dlg->AddTextfield(-name => $name, -text => $value, -left => 73, -top => $row, -width => 200, -height => 16, -tabstop => 1, );
#$Dlg->AddTextfield(-name => $name, -prompt => $label, -text => $value, -left => 73, -top => $row, -width => 200, -height => 16, -tabstop => 1);
$Dlg->$name->SetWindowLong($GWL_ID, $id++);
$row += 24;
}

$row += 6;
$Dlg->AddButton(-name => 'OK', -caption => 'OK',	-left => 39, -top => $row, -width => 100, -height => 16, -align => 'center', -valign => 'center', -tabstop => 1, -ok => 1, -default => 1, -onClick => sub {$i = 0; while ($i < $count) {$i ++; $name = 'Input' . $i;
$Result .= $Dlg->$name->Text() . "\007";} $Result = substr($Result, 0, length($Result) - 1); return -1;});
$Dlg->AddButton(-name => 'Cancel', -caption => 'Cancel',	-left => 147, -top => $row, -width => 100, -height => 16, -align => 'center', -valign => 'center', -tabstop => 1, -cancel => 1, -onClick => sub {return -1;});

$Dlg->Input1->SetFocus();
$Dlg->Input1->SelectAll();
$Dlg->Center();
$Dlg->Show();
$Dlg->SetForegroundWindow();
Win32::GUI::Dialog();
$Dlg->DESTROY();

if ($StandAlone) {
print "Result=$Result\n";
}
else {
scalar $Result;
}
