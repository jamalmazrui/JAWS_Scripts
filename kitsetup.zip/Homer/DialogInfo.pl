my $StandAlone = 1;
if ($StandAlone) {
use strict;
use warnings;
use Win32::GUI;
}
my ($p1, $p2, $p3, $p4) = $StandAlone ? ('Memo', "This is line 1\r\nline 2 is here", 0, 0) : ($p1, $p2, $p3, $p4);

Win32::GUI->import(qw(ES_WANTRETURN GW_HWNDNEXT GW_HWNDPREV GW_HWNDLAST GW_HWNDFIRST));
package Win32::GUI;

sub TabKey {
my $hFocus = GetFocus();
my $hTarget = GetWindow($hFocus, GW_HWNDNEXT);
$hTarget = GetWindow($hFocus, GW_HWNDFIRST) if $hTarget <= 0;
SetFocus($hTarget);
}

sub ShiftTabKey {
my $hFocus = GetFocus();
my $hTarget = GetWindow($hFocus, GW_HWNDPREV);
print "$hTarget \n";
$hTarget = GetWindow($hFocus, GW_HWNDLAST) if $hTarget <= 0;
SetFocus($hTarget);
}

my $Result = '';
my $Keyboard = Win32::GUI::AcceleratorTable->new(Escape => sub {return -1;}, Tab => \&TabKey, "Shift-Tab" => \&ShiftTabKey);
my $Dlg = Win32::GUI::DialogBox->new(-name => 'Dlg', -title => $p1, -width => 434, -height => 483, -accel => $Keyboard, -onTerminate => sub {return -1;}, -dialogui => 1);
$Dlg->AddTextfield(-name => 'Memo', -text => $p2, -left => 14, -top => 14, -width => 400, -height => 400, -tabstop => 1, -multiline => 1, -vscroll => 1, -autovscroll => 1, -readonly => 1, -popstyle => ES_WANTRETURN );
$Dlg->AddButton(-name => 'OK', -caption => 'OK',	-left => 14, -top => 428, -width => 100, -height => 16, -align => 'center', -valign => 'center', -tabstop => 1, -ok => 1, -default => 1, -onClick => sub {return -1;}, -onDblClick => sub {return -1;});

$Dlg->Memo->SetFocus();
$Dlg->Center();
if (0) {
$Dlg->DoModal();
}
else {
$Dlg->Show();
$Dlg->SetForegroundWindow();
Win32::GUI::Dialog();
}
$Dlg->DESTROY();

if ($StandAlone) {
print "Result=$Result\n";
}
else {
scalar $Result;
}
