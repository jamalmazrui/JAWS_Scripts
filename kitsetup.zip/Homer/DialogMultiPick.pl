my $StandAlone = 0;
if ($StandAlone) {
use strict;
use warnings;
use Win32::GUI;
}
my ($p1, $p2, $p3, $p4) = $StandAlone ? ('Multiple Select', 'apple|cherry|banana|date', 1, 2) : ($p1, $p2, $p3, $p4);

Win32::GUI->import(qw(ES_WANTRETURN GW_HWNDNEXT GW_HWNDPREV GW_HWNDLAST GW_HWNDFIRST));
package Win32::GUI;
my $Result = '';

my $Dlg = Win32::GUI::DialogBox->new(-name => 'Dlg', -title => $p1, -width => 434, -height => 483, -onTerminate => sub {return -1;});
$Dlg->AddListbox(-name => 'Multi', -left => 14, -top => 14, -width => 400, -height => 400, -tabstop => 1, -multisel => 1, -sort => $p3, -notify => 1, -usetabstops => 1);
my @a = split /\|/, $p2;
$Dlg->Multi->Add(@a);
$Dlg->Multi->SetCaretIndex($p4) if defined($p4) && p4 >= 0;

$Dlg->AddButton(-name => 'OK', -caption => 'OK',	-left => 110, -top => 428, -width => 100, -height => 16, -align => 'center', -valign => 'center', -tabstop => 1, -ok => 1, -default => 1, -onClick => sub {$Result = join('|', map {$Dlg->Multi->GetString($_)} $Dlg->Multi->GetSelItems()); return -1;});
$Dlg->AddButton(-name => 'Cancel', -caption => 'Cancel',	-left => 218, -top => 428, -width => 100, -height => 16, -align => 'center', -valign => 'center', -tabstop => 1, -cancel => 1, -onClick => sub {return -1;});

$Dlg->Multi->SetFocus();
$Dlg->Center();
$Dlg->Show();
$Dlg->SetForegroundWindow();
Win32::GUI::Dialog();
$Dlg->DESTROY();

if ($StandAlone) {
print "Result=$Result\n";
}
else {
scalar $Result;
}

