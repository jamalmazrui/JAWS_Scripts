#PerlEval
#Version 1.1
#May 4, 2007
#Copyright 2006-2007 by Jamal Mazrui
#Modified GPL License

package PerlEval;
#use strict;
use warnings;
#use English;
use Win32;
use Win32::API;
use Win32::API::Callback;
#use Win32::DDE;
#use Win32::ChangeNotify;
#use Win32::Event;
#use Win32::Mutex;
#use Win32::Semaphore;

use Win32::OLE;
use Win32::OLE::Const;
use Win32::OLE::Variant;
#use Win32Util;
use Win32::GUI;
#use Win32::GuiTest qw(:ALL :SW);
use Win32::GuiTest;
use Win32::ActAcc;
#use Win32::GUI::Carp qw/warningsToDialog/;
#use Win32::GUI::Carp qw/fatalsToDialog/;
#use Win32::Clipboard;
#use Win32::Console;
#use Win32::File;
#use Win32::FileOp;
#use Win32::FileTime;
use File::OldSlurp;
#use Win32::Process;
#use Win32::Process::Info;
#use Win32::Script;
#use Win32::Service;
#use Win32::Shortcut ();
#use Win32::Screenshot;
#use Win32::Sound;
#use Win32::Registry;
#use Win32::TieRegistry;
#use Win32::TaskScheduler;
#use Win32::WinError;
use Win32::FetchCommand;
#use Win32::DirSize;
#use Win32::ToolHelp;
#use Win32::AdminMisc;
#use CAM::PDF;
#use Getopt::Long;
#use Pod::Usage;

#use Win32::Exchange;
#use Win32::MSAgent;
#use File::Find;

#use File::Basename;
#use Win32::Exe;
#use Date::Calc qw(:all);
use Date::Calc;
#use List::Util qw(first max maxstr min minstr reduce shuffle sum);
#use List::Util;
#use Scalar::Util;
#use String::Util;
use Text::Autoformat;
use Text::Reform;

#use LWP;
#use LWP::Simple;
#use LWP::UserAgent;
#use URI;
#use HTML::LinkExtor;
#use HTML::TokeParser;
#use HTML::HeadParser;
#use HTML::Parser;
#use HTML::Tagset;
#use warnings;
                  
sub Eval {
my ($p0, $p1, $p2, $p3, $p4) = @_;
eval($p0);
#return $@ if $@;
}

=pod

=begin PerlCtrl

    %TypeLib = (
	PackageName     => 'PerlEval',
        DocString       => 'My very own control',
        HelpFileName    => 'MyControl.chm',
        HelpContext     => 1,
	TypeLibGUID     => '{FC6B8A85-C5CF-4619-B92C-510A9BA5DAE3}', # do NOT edit this line
	ControlGUID     => '{17B19BE4-85C1-47CB-AE3F-72380E9A8EA9}', # do NOT edit this line either
	DispInterfaceIID=> '{A43CA4C6-396A-40EF-8969-E2F9FB43A01C}', # or this one
	ControlName     => 'Control',
	ControlVer      => 1,  # increment if new object with same ProgID
			       # create new GUIDs as well
	ProgID          => 'Perl.Eval',
        LCID            => 0,
	DefaultMethod   => 'Eval',
	Methods         => {
	    Eval => {
                DocString           => "The Eval method",
                HelpContext         => 101,

                DispID              =>  0,
		RetType             =>  VT_BSTR,
		TotalParams         =>  5,
		NumOptionalParams   =>  4,
		ParamList           =>[ ParamName1 => VT_BSTR,
					ParamName2 => VT_BSTR,
					ParamName3 => VT_BSTR,
					ParamName4 => VT_BSTR,
					ParamName5 => VT_BSTR ],
	    },
	    MyMethodName2 => {
                DocString           => "The MyMethodName2 method",
                HelpContext         => 102,

                DispID              =>  1,
		RetType             =>  VT_I4,
		TotalParams         =>  2,
		NumOptionalParams   =>  0,
		ParamList           =>[ ParamName1 => VT_I4,
					ParamName2 => VT_BSTR ],
	    },
	},  # end of 'Methods'
	Properties        => {
	    MyIntegerProp => {
                DocString         => "The MyIntegerProp property",
                HelpContext       => 201,

                DispID            => 2,
		Type              => VT_I4,
		ReadOnly          => 0,
	    },
	    MyStringProp => {
                DocString         => "The MyStringProp property",
                HelpContext       => 202,

                DispID            => 3,
		Type              => VT_BSTR,
		ReadOnly          => 0,
	    },
	    Color => {
                DocString         => "The Color property",
                HelpContext       => 203,

                DispID            => 4,
		Type              => VT_BSTR,
		ReadOnly          => 0,
	    },
	    MyReadOnlyIntegerProp => {
                DocString         => "The MyReadOnlyIntegerProp property",
                HelpContext       => 204,

                DispID            => 5,
		Type              => VT_I4,
		ReadOnly          => 1,
	    },
	},  # end of 'Properties'
    );  # end of %TypeLib

=end PerlCtrl

=cut
