/*
import Iron;
import System;

var s1 = "Multi Input";
var s2 = "Label1\tLabel2\tLabel3";
var s3 = "Value1\tValue2\tValue3";
var s4 = "\t";
*/

var sDelimiter = s4;
var sTitle = s1;
var aLabels = s2.Split(sDelimiter[0]);
var aValues = s3.Split(sDelimiter[0]);
var aResults = Dialog.MultiInput(sTitle, aLabels, aValues);
var sReturn = String.Join(sDelimiter, aResults);
